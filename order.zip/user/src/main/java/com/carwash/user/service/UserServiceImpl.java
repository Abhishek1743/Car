package com.carwash.user.service;

import com.carwash.user.dto.UserLoginDTO;
import com.carwash.user.dto.UserLoginResponse;
import com.carwash.user.dto.UserSignupDTO;
import com.carwash.user.entity.User;
import com.carwash.user.repository.UserRepository;
import com.carwash.user.security.JwtUtil;
import com.carwash.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Override
    public void register(UserSignupDTO signupDTO) {
        User user = User.builder()
                .username(signupDTO.getUsername())
                .password(passwordEncoder.encode(signupDTO.getPassword()))
                .role(signupDTO.getRole())
                .build();
        userRepository.save(user);
    }

    @Override
    public UserLoginResponse login(UserLoginDTO loginDTO) {
        User user = userRepository.findByUsername(loginDTO.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }
        String token = jwtUtil.generateToken(user.getUsername());
        return new UserLoginResponse(token);
    }
}