package com.carwash.user.dto;

import lombok.Data;

@Data
public class UserLoginDTO {
    private String username;
    private String password;
}