package com.carwash.user.service;

import com.carwash.user.dto.UserLoginDTO;
import com.carwash.user.dto.UserLoginResponse;
import com.carwash.user.dto.UserSignupDTO;

public interface UserService {
    void register(UserSignupDTO signupDTO);
    UserLoginResponse login(UserLoginDTO loginDTO);
}