package com.carwash.CarWash.controller;

import com.carwash.CarWash.entity.WashRequest;
import com.carwash.CarWash.service.WashService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wash")
@RequiredArgsConstructor
public class WashController {

    private final WashService washService;

    @PostMapping("/request")
    public ResponseEntity<WashRequest> createRequest(@RequestBody WashRequest request) {
        return ResponseEntity.ok(washService.createRequest(request));
    }

    @PutMapping("/assign/{id}")
    public ResponseEntity<WashRequest> assignWasher(@PathVariable Long id, @RequestParam Long washerId) {
        return ResponseEntity.ok(washService.assignWasher(id, washerId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<WashRequest> getById(@PathVariable Long id) {
        return ResponseEntity.ok(washService.getRequestById(id));
    }

    @GetMapping
    public ResponseEntity<List<WashRequest>> getAll() {
        return ResponseEntity.ok(washService.getAllRequests());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        washService.deleteRequest(id);
        return ResponseEntity.ok("Deleted");
    }
}