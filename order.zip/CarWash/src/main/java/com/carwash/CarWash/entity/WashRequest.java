package com.carwash.CarWash.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WashRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long washerId;
    private String carModel;
    private String washType; // Basic, Premium, etc.
    private String status;   // REQUESTED, ASSIGNED, COMPLETED
    private LocalDateTime requestDate;
}