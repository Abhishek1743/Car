package com.carwash.CarWash.repository;

import com.carwash.CarWash.entity.WashRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WashRequestRepository extends JpaRepository<WashRequest, Long> {
}