package com.carwash.CarWash.service;


import com.carwash.CarWash.entity.WashRequest;

import java.util.List;

public interface WashService {
    WashRequest createRequest(WashRequest request);
    WashRequest assignWasher(Long id, Long washerId);
    WashRequest getRequestById(Long id);
    List<WashRequest> getAllRequests();
    void deleteRequest(Long id);
}