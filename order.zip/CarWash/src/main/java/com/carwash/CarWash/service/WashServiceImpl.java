package com.carwash.CarWash.service;

import com.carwash.CarWash.entity.WashRequest;
import com.carwash.CarWash.repository.WashRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WashServiceImpl implements WashService {

    private final WashRequestRepository repository;

    @Override
    public WashRequest createRequest(WashRequest request) {
        request.setStatus("REQUESTED");
        request.setRequestDate(LocalDateTime.now());
        return repository.save(request);
    }

    @Override
    public WashRequest assignWasher(Long id, Long washerId) {
        WashRequest request = repository.findById(id).orElseThrow(() -> new RuntimeException("Request not found"));
        request.setWasherId(washerId);
        request.setStatus("ASSIGNED");
        return repository.save(request);
    }

    @Override
    public WashRequest getRequestById(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Request not found"));
    }

    @Override
    public List<WashRequest> getAllRequests() {
        return repository.findAll();
    }

    @Override
    public void deleteRequest(Long id) {
        repository.deleteById(id);
    }
}
