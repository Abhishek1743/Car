package com.carwash.order.dto;

import lombok.Data;

@Data
public class OrderRequest {
    private Long userId;
    private String carModel;
    private String washPackage;
}