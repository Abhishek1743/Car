package com.carwash.order.service;

import com.carwash.order.dto.OrderRequest;
import com.carwash.order.dto.OrderResponse;
import com.carwash.order.entity.Order;
import com.carwash.order.repository.OrderRepository;
import com.carwash.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository repository;

    @Override
    public OrderResponse placeOrder(OrderRequest request) {
        Order order = Order.builder()
                .userId(request.getUserId())
                .carModel(request.getCarModel())
                .washPackage(request.getWashPackage())
                .status("PENDING")
                .build();
        repository.save(order);
        return OrderResponse.builder()
                .orderId(order.getId())
                .status(order.getStatus())
                .build();
    }

    @Override
    public List<OrderResponse> getOrdersByUser(Long userId) {
        return repository.findByUserId(userId).stream()
                .map(order -> OrderResponse.builder()
                        .orderId(order.getId())
                        .status(order.getStatus())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    public List<OrderResponse> getAllOrders() {
        return repository.findAll().stream()
                .map(order -> OrderResponse.builder()
                        .orderId(order.getId())
                        .status(order.getStatus())
                        .build())
                .collect(Collectors.toList());
    }
}