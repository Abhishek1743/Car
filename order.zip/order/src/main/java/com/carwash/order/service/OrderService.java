package com.carwash.order.service;

import com.carwash.order.dto.OrderRequest;
import com.carwash.order.dto.OrderResponse;

import java.util.List;

public interface OrderService {
    OrderResponse placeOrder(OrderRequest request);
    List<OrderResponse> getOrdersByUser(Long userId);
    List<OrderResponse> getAllOrders();
}